<?php

namespace App\Console\Commands;

use App\Mail\BirthdayGreetings;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;

class SendBirthdayGreetings extends Command
{
    protected $signature = 'birthday:greetings';

    protected $description = 'Send birthday greetings to users';

    public function handle()
    {
        $users = User::whereDay('birthday', Carbon::now()->day)
            ->whereMonth('birthday', Carbon::now()->month)
            ->get();

        foreach ($users as $user) {
            Mail::to($user->email)->send(new BirthdayGreetings($user));
        }

        $this->info('Birthday greetings sent successfully.');
    }
}
