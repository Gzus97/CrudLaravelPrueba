<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('Has iniciado!')); ?>

                </div>
                <div>
                    <table>
                        <thead>
                        <tr>
                            <th colspan="8">
                                <h1>
                                    Usuarios
                                </h1>
                            </th>
                        </tr>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Creado</th>
                            <th>Actualizado</th>
                            <th>Edad</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $usuariosdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($usuario->id); ?></td>
                                <td><?php echo e($usuario->name); ?></td>
                                <td><?php echo e($usuario->email); ?></td>
                                <td><?php echo e($usuario->created_at); ?></td>
                                <td><?php echo e($usuario->updated_at); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($usuario->birthday)->age); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Crud090523\crudlogin\resources\views/home.blade.php ENDPATH**/ ?>